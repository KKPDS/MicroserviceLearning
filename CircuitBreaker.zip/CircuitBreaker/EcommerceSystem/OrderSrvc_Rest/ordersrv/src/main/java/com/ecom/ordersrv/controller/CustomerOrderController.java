package com.ecom.ordersrv.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecom.ordersrv.exception.InventoryNotFoundException;
import com.ecom.ordersrv.model.CustomerOrder;
import com.ecom.ordersrv.service.CustomerOrderService;

@RestController
@RequestMapping("api/customerorders")
public class CustomerOrderController {
	@Autowired
	CustomerOrderService customerOrderService;
	
	@GetMapping
	public List<CustomerOrder> getCustomerOrders() throws Exception{
		List<CustomerOrder> customerOrders = customerOrderService.getCustomerOrders();
		return customerOrders;
	}

	@GetMapping(value ="{id}")
	public ResponseEntity<CustomerOrder> getCustomerOrder(@PathVariable Long id) throws Exception{
		CustomerOrder customerOrder = customerOrderService.getCustomerOrderById(id);
		return ResponseEntity.ok(customerOrder);
	}

	@PostMapping
	public ResponseEntity<Object> addCustomerOrder(@RequestBody CustomerOrder customerOrder) throws InventoryNotFoundException {
		// CustomerOrder savedcustomerOrder = customerOrderService.addCustomerOrder(customerOrder);
		return ResponseEntity.ok(customerOrderService.addCustomerOrder(customerOrder));
	}

	@PutMapping(value = "{id}")
	public CustomerOrder updateCustomerOrder(@PathVariable Long id, @RequestBody CustomerOrder customerOrder) throws Exception {
		return customerOrderService.updateCustomerOrder(id, customerOrder);
	}
	
	@DeleteMapping(value = "{id}")
	public String removeCustomerOrder(@PathVariable Long id) throws Exception {
		customerOrderService.removeCustomerOrder(id);
		return "OK";
	}
    
}
