package com.ecom.inventorysrv.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecom.inventorysrv.model.Inventory;
import com.ecom.inventorysrv.service.InventoryService;


@RestController
@RequestMapping("api/inventories")
public class InventoryController {
	@Autowired
	InventoryService inventoryService;
	
	@GetMapping
	public List<Inventory> getInventorys() throws Exception{
		List<Inventory> inventorys = inventoryService.getInventorys();
		return inventorys;
	}

	@GetMapping(value ="{id}")
	public ResponseEntity<Inventory> getInventory(@PathVariable Long id) throws Exception{
		Inventory inventory = inventoryService.getInventoryById(id);
		return ResponseEntity.ok(inventory);
	}

	@PostMapping
	public ResponseEntity<Inventory> addInventory(@RequestBody Inventory inventory) throws Exception {
		Inventory savedinventory = inventoryService.addInventory(inventory);
		return ResponseEntity.ok(savedinventory);
	}

	@PutMapping(value = "{id}")
	public Inventory updateInventory(@PathVariable Long id, @RequestBody Inventory inventory) throws Exception {
		return inventoryService.updateInventory(id, inventory);
	}
	
	@DeleteMapping(value = "{id}")
	public String removeInventory(@PathVariable Long id) throws Exception {
		inventoryService.removeInventory(id);
		return "OK";
	}
    
}

