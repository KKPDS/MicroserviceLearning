package com.ecom.inventorysrv.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecom.inventorysrv.model.Inventory;
import com.ecom.inventorysrv.repository.InventoryRepository;

@Service
public class InventoryService {
    private static final Logger log = LoggerFactory.getLogger(InventoryService.class);

    @Autowired
    InventoryRepository inventoryRepository;

	public List<Inventory> getInventorys() throws Exception{
		try {
			return (List<Inventory>) inventoryRepository.findAll();
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public Inventory getInventoryById(Long inventoryid) throws Exception{
		Inventory inventory = null;
		try {
			inventory = inventoryRepository.findById(inventoryid).orElse(null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return inventory;
	}

	public Inventory addInventory(Inventory inventory) throws Exception{
		try {
			return inventoryRepository.save(inventory);
		} catch (Exception pe) {
			pe.printStackTrace();
		}
		return null;
	}
	
	public Inventory updateInventory(Long inventoryid, Inventory inventory) throws Exception {
		Inventory existinginventory = inventoryRepository.findById(inventoryid).orElse(null);
		if (null != existinginventory) {
			existinginventory.setId(inventory.getId());
			existinginventory.setName(inventory.getName());
			existinginventory.setDescription(inventory.getDescription());
            existinginventory.setPrice(inventory.getPrice());
            existinginventory.setQuantity(inventory.getQuantity());
			return inventoryRepository.save(existinginventory);
		} else {
            log.info("Inventory not found in DB !!!");
        }
		return null;
	}
	
	public void removeInventory(Long inventoryid) throws Exception{
		try {
			inventoryRepository.deleteById(inventoryid);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}    

}
