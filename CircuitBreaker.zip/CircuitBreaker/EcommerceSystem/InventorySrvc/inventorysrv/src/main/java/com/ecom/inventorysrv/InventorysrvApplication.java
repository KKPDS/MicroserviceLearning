package com.ecom.inventorysrv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventorysrvApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventorysrvApplication.class, args);
	}

}
