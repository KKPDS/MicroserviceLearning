package com.ecom.ordersrv.client;

import java.net.ConnectException;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.ecom.ordersrv.config.FeignConfig;
import com.ecom.ordersrv.dto.InventoryItem;

@FeignClient(name = "inventory-service", url = "http://localhost:8081", configuration = FeignConfig.class)
public interface InventoryClient {
    @GetMapping(value = "/api/inventories/{id}")
    InventoryItem getInventoryById(@PathVariable Long id);    
}
