package com.ecom.ordersrv.exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;


@ControllerAdvice
public class AppExceptionHandler {
    
    @ExceptionHandler(value={InventoryNotFoundException.class})
    public ResponseEntity<Object> handleInventoryNotFoundException(InventoryNotFoundException ex) {
        Map<String, String> errorMap=new HashMap<>();
        errorMap.put("errorMsg", ex.getMessage());
        return new ResponseEntity<>(errorMap, HttpStatus.BAD_REQUEST);
    }

    // @ExceptionHandler(value={InventoryServiceDownException.class})
    // public ResponseEntity<Object> handleInventoryServiceDownException(InventoryServiceDownException ex) {
    //     Map<String, String> errorMap=new HashMap<>();
    //     errorMap.put("errorMsg", ex.getMessage());
    //     return new ResponseEntity<>(errorMap, HttpStatus.INTERNAL_SERVER_ERROR);
    // }    

}
