package com.ecom.ordersrv.service;

import java.net.ConnectException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.ecom.ordersrv.client.InventoryClient;
import com.ecom.ordersrv.dto.InventoryItem;
import com.ecom.ordersrv.exception.InventoryNotFoundException;
import com.ecom.ordersrv.exception.InventoryServiceDownException;
import com.ecom.ordersrv.model.CustomerOrder;
import com.ecom.ordersrv.repository.CustomerOrderRepository;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Service
public class CustomerOrderService {
    private static final Logger log = LoggerFactory.getLogger(CustomerOrderService.class);
    
    @Autowired
    CustomerOrderRepository customerOrderRepository;

    @Autowired
    InventoryClient inventoryClient;

    private static final String SERVICE_NAME = "inventory-service";

	private static final String INVENTORY_FOUND = "Inventory Found";
	private static final String INVENTORY_NOT_FOUND = "Inventory Not Found";
	private static final String INVENTORY_SERVICE_DOWN = "Inventory Service is Down";
	private static final String INVENTORY_UNKNOWN_ERROR = "Unknown Error";

	public List<CustomerOrder> getCustomerOrders() throws Exception{
		try {
			return (List<CustomerOrder>) customerOrderRepository.findAll();
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public CustomerOrder getCustomerOrderById(Long customerorderid) throws Exception{
		CustomerOrder customerorder = null;
		try {
			customerorder = customerOrderRepository.findById(customerorderid).orElse(null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return customerorder;
	}

	@CircuitBreaker(name = SERVICE_NAME, fallbackMethod = "circuitFallBackMethod")
	public ResponseEntity<Object> addCustomerOrder(CustomerOrder customerorder) {
		Map<String, String> errorMap=new HashMap<>();
		String item = this.checkInventory(customerorder.getItemId());
		if (item.equalsIgnoreCase(INVENTORY_FOUND)) {
			return new ResponseEntity<>(customerOrderRepository.save(customerorder), HttpStatus.CREATED);
		} else if (item.equalsIgnoreCase(INVENTORY_NOT_FOUND)) {
			log.info("inventory not found with id: " + customerorder.getItemId());
			errorMap.put("errorMsg", INVENTORY_NOT_FOUND);
		} else {
			log.info("seems inventory service is down ");
			errorMap.put("errorMsg", INVENTORY_UNKNOWN_ERROR);
		}
		return new ResponseEntity<>(errorMap, HttpStatus.BAD_REQUEST);
	}

    @CircuitBreaker(name = SERVICE_NAME, fallbackMethod = "circuitFallBackMethod")
    public String checkInventory(Long itemId) throws InventoryServiceDownException {
        // RestTemplate call to InventoryService
		InventoryItem item = this.inventoryClient.getInventoryById(itemId);
		String result = "";
		if (null != item) {
			result = INVENTORY_FOUND;
		} else {
			result = INVENTORY_NOT_FOUND;
		}
		return result;

    }

    public ResponseEntity<Object> circuitFallBackMethod(CustomerOrder customerorder, Throwable t) {
        // Fallback logic
		log.info("Item loading failed ..., fall back called");
        Map<String, String> errorMap=new HashMap<>();
        errorMap.put("errorMsg", INVENTORY_SERVICE_DOWN);
		return new ResponseEntity<>(errorMap, HttpStatus.INTERNAL_SERVER_ERROR);
    }

	
	public CustomerOrder updateCustomerOrder(Long customerorderid, CustomerOrder order) throws Exception {
		CustomerOrder existingcustomerorder = customerOrderRepository.findById(customerorderid).orElse(null);
		if (null != existingcustomerorder) {
			existingcustomerorder.setId(order.getId());
			existingcustomerorder.setProduct(order.getProduct());
			existingcustomerorder.setCustomerId(order.getCustomerId());
            existingcustomerorder.setItemId(order.getItemId());
			return customerOrderRepository.save(existingcustomerorder);
		} else {
            log.info("Customer Order not found in DB !!!");
        }
		return null;
	}
	
	public void removeCustomerOrder(Long customerorderid) throws Exception{
		try {
			customerOrderRepository.deleteById(customerorderid);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

}
