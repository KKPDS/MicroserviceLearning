package com.ecom.ordersrv.exception;

public class InventoryServiceDownException extends RuntimeException{
    
    public InventoryServiceDownException(String msg) {
        super(msg);
    }
}
