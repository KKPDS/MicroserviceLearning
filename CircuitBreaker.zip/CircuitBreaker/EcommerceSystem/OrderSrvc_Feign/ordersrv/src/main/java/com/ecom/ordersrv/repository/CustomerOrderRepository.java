package com.ecom.ordersrv.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ecom.ordersrv.model.CustomerOrder;

public interface CustomerOrderRepository extends JpaRepository<CustomerOrder, Long> {
    
} 
