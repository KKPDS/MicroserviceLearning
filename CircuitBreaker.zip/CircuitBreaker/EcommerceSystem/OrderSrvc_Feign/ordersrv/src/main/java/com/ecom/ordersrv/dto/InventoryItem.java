package com.ecom.ordersrv.dto;

import java.math.BigDecimal;

public class InventoryItem {
    Integer id;
    String name;
    String description;
    BigDecimal price;
    Long quantity;
}
