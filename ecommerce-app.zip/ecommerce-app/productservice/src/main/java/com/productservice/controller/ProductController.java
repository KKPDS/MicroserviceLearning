package com.productservice.controller;

import com.productservice.model.Product;
import com.productservice.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/products")
public class ProductController {

	@Autowired
	ProductService productService;
	
	@GetMapping
	public List<Product> getProducts() throws Exception{
		List<Product> products = productService.getProducts();
		return products;
	}

	@GetMapping(value ="{id}")
	public Product getProduct(@PathVariable Long id) throws Exception{
		Product product = productService.getProductById(id);
		return product;
	}

	@PostMapping
	public Product addProduct(@RequestBody Product product) throws Exception {
		return productService.addProduct(product);
	}

	@PutMapping(value = "{id}")
	public Product updateProduct(@PathVariable Long id, @RequestBody Product product) throws Exception {
		return productService.updateProduct(id, product);
	}
	
	@DeleteMapping(value = "{id}")
	public String removeProduct(@PathVariable Long id) throws Exception {
		productService.removeProduct(id);
		return "OK";
	}

}
