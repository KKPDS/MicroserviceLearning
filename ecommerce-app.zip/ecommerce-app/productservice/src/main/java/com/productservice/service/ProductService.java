package com.productservice.service;

import com.productservice.model.Product;
import com.productservice.repository.ProductRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class ProductService {
	private static final Logger log = LoggerFactory.getLogger(ProductService.class);

	@Autowired
	ProductRepository productRepository;

	public List<Product> getProducts() throws Exception{
		try {
			return (List<Product>) productRepository.findAll();
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public Product getProductById(Long productid) throws Exception{
		Product product = null;
		try {
			product = productRepository.findById(productid).orElse(null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return product;
	}

	public Product addProduct(Product product) throws Exception{
		try {
			return productRepository.save(product);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public Product updateProduct(Long productid, Product product) throws Exception {
		try {
			Product existingproduct = productRepository.findById(productid).orElse(null);
			if (null != existingproduct) {
				existingproduct.setName(product.getName());
				existingproduct.setPrice(product.getPrice());
				return productRepository.save(existingproduct);
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return null;
	}
	
	public void removeProduct(Long productid) throws Exception{
		try {
			productRepository.deleteById(productid);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	
}
