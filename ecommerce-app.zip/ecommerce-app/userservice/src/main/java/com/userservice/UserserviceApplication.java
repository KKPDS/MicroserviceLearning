package com.userservice;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.info.License;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@OpenAPIDefinition(
		info = @Info(
				title = "eCommerce - User Service",
				version = "1.0.0",
				description = "Sample demo project",
				termsOfService = "open_to_all_page",
				contact = @Contact(
						name = "KK",
						email = "emailme@email.com"
				),
				license = @License(
						name = "License",
						url ="testurl.com"
				)
		)
)
public class UserserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserserviceApplication.class, args);
	}

}
