package com.userservice.controller;

import com.userservice.model.User;
import com.userservice.service.UserService;
import com.userservice.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/users")
public class UserController {

	@Autowired
	UserService userService;
	
	@GetMapping
	public List<User> getUsers() throws Exception{
		List<User> users = userService.getUsers();
		return users;
	}

	@GetMapping(value ="{id}")
	public User getUser(@PathVariable Long id) throws Exception{
		User user = userService.getUserById(id);
		return user;
	}

	@PostMapping
	public User addUser(@RequestBody User user) throws Exception {
		return userService.addUser(user);
	}

	@PutMapping(value = "{id}")
	public User updateUser(@PathVariable Long id, @RequestBody User user) throws Exception {
		return userService.updateUser(id, user);
	}
	
	@DeleteMapping(value = "{id}")
	public String removeUser(@PathVariable Long id) throws Exception {
		userService.removeUser(id);
		return "OK";
	}

}
