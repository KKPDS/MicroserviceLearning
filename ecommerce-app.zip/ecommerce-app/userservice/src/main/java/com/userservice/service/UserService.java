package com.userservice.service;

import com.userservice.model.User;
import com.userservice.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {
    private static final Logger log = LoggerFactory.getLogger(UserService.class);

    @Autowired
    UserRepository userRepository;

    public List<User> getUsers() throws Exception{
        try {
            return (List<User>) userRepository.findAll();
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    public User getUserById(Long userid) throws Exception{
        User user = null;
        try {
            user = userRepository.findById(userid).orElse(null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return user;
    }

    public User addUser(User user) throws Exception{
        try {
            return userRepository.save(user);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public User updateUser(Long userid, User user) throws Exception {
        try {
            User existinguser = userRepository.findById(userid).orElse(null);
            if (null != existinguser) {
                existinguser.setName(user.getName());
                existinguser.setAddress(user.getAddress());
                return userRepository.save(existinguser);
            }
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
        return null;
    }

    public void removeUser(Long userid) throws Exception{
        try {
            userRepository.deleteById(userid);
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

}
