package com.orderservice.service;

import com.orderservice.client.ProductClient;
import com.orderservice.client.UserClient;
import com.orderservice.exception.UserNotFoundException;
import com.orderservice.exception.UserOrderNotFoundException;
import com.orderservice.exception.ProductNotFoundException;
import com.orderservice.model.User;
import com.orderservice.model.UserOrder;
import com.orderservice.model.Product;
import com.orderservice.repository.UserOrderRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class UserOrderService {
	private static final Logger log = LoggerFactory.getLogger(UserOrderService.class);

	@Autowired
	UserOrderRepository orderRepository;

	@Autowired
	private ProductClient productClient;

	@Autowired
	private UserClient userClient;

	public List<UserOrder> getUserOrders() throws Exception{
		try {
			return (List<UserOrder>) orderRepository.findAll();
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public UserOrder getUserOrderById(Long orderid) throws Exception{
		UserOrder order = null;
		try {
			order = orderRepository.findById(orderid).orElse(null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return order;
	}

	public UserOrder addUserOrder(UserOrder order) throws Exception{
		try {
			Product product = productClient.getProductById(order.getProductId());
			User user = userClient.getUserById(order.getUserId());
			if (null != product && null != user) {
				return orderRepository.save(order);
			} else {
				if (null == product) {
					throw new ProductNotFoundException("Product Not Found !!!");
				}
				if (null == user) {
					throw new UserNotFoundException("User Not Found !!!");
				}
			}
		} catch (ProductNotFoundException pe) {
			pe.printStackTrace();
		} catch (UserNotFoundException ue) {
			ue.printStackTrace();
		}
		return null;
	}
	
	public UserOrder updateUserOrder(Long orderid, UserOrder order) throws Exception {
		UserOrder existingorder = orderRepository.findById(orderid).orElse(null);
		if (null != existingorder) {
			Product product = productClient.getProductById(existingorder.getProductId());

			if (null != product) {
				existingorder.setUserId(order.getUserId());
				existingorder.setProductId(order.getProductId());
				return orderRepository.save(existingorder);
			} else {
				throw new ProductNotFoundException("Product Not Found !!!");
			}
		} else {
			throw new UserOrderNotFoundException("UserOrder Not Found !!!");
		}
	}
	
	public void removeUserOrder(Long orderid) throws Exception{
		try {
			orderRepository.deleteById(orderid);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	
}
