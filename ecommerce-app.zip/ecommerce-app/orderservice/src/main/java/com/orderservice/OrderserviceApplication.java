package com.orderservice;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.info.License;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@OpenAPIDefinition(
		info = @Info(
				title = "eCommerce - Order Service",
				version = "1.0.0",
				description = "Sample demo project",
				termsOfService = "open_to_all_page",
				contact = @Contact(
						name = "KK",
						email = "emailme@email.com"
				),
				license = @License(
						name = "License",
						url ="testurl.com"
				)
		)
)
@EnableFeignClients
public class OrderserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderserviceApplication.class, args);
	}

}
