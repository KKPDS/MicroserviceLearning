package com.orderservice.config;

import feign.Logger;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@RequiredArgsConstructor
public class FeignConfig {
    @Bean
    public feign.Logger.Level feignLoggerLevel(){ return Logger.Level.FULL; }
}
