package com.orderservice.controller;

import com.orderservice.model.UserOrder;
import com.orderservice.service.UserOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/orders")
public class UserOrderController {

	@Autowired
	UserOrderService orderService;
	
	@GetMapping
	public List<UserOrder> getUserOrders() throws Exception{
		List<UserOrder> orders = orderService.getUserOrders();
		return orders;
	}

	@GetMapping(value ="{id}")
	public UserOrder getUserOrder(@PathVariable Long id) throws Exception{
		UserOrder order = orderService.getUserOrderById(id);
		return order;
	}

	@PostMapping
	public UserOrder addUserOrder(@RequestBody UserOrder order) throws Exception {
		return orderService.addUserOrder(order);
	}

	@PutMapping(value = "{id}")
	public UserOrder updateUserOrder(@PathVariable Long id, @RequestBody UserOrder order) throws Exception {
		return orderService.updateUserOrder(id, order);
	}
	
	@DeleteMapping(value = "{id}")
	public String removeUserOrder(@PathVariable Long id) throws Exception {
		orderService.removeUserOrder(id);
		return "OK";
	}

}
