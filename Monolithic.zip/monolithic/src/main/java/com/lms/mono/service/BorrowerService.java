package com.lms.mono.service;

import com.lms.mono.entity.Book;
import com.lms.mono.entity.Borrower;
import com.lms.mono.repository.BookRepository;
import com.lms.mono.repository.BorrowerRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;


@Service
public class BorrowerService {
	private static final Logger log = LoggerFactory.getLogger(BorrowerService.class);

	@Autowired
	BorrowerRepository borrowerRepo;

	@Autowired
	BookService bookService;

	public List<Borrower> getBorrowers() throws Exception{
		try {
			return (List<Borrower>) borrowerRepo.findAll();
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	public Borrower getBorrowerById(Integer borrowerid) throws Exception{
		Borrower borrower = null;
		try {
			borrower = borrowerRepo.findById(borrowerid).orElse(null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return borrower;
	}
	
	public void addBorrower(Borrower borrower) throws Exception{
		try {
			Book book = bookService.getBookById(borrower.getBook().getId());
			if (null != book) {
				borrowerRepo.save(borrower);
				book.setStatus("BORROWED");
				bookService.updateBook(book.getId(), book);
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	public void updateBorrower(Integer borrowerid, Borrower borrower) throws Exception{
		try {
			Borrower existingborrower = borrowerRepo.findById(borrowerid).orElse(null);
			if (null != existingborrower) {
				Book book = bookService.getBookById(borrower.getBook().getId());
				existingborrower.setBook(book);
				existingborrower.setBorrowDate(borrower.getBorrowDate());
				existingborrower.setReturnDate(borrower.getReturnDate());
				existingborrower.setUser(borrower.getUser());
				borrowerRepo.save(existingborrower);
				if (null != borrower.getReturnDate() && null != book) {
					book.setStatus("AVAILABLE");
					bookService.updateBook(book.getId(), book);
				}
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	public void removeBorrower(Integer borrowerid) throws Exception{
		try {
			borrowerRepo.deleteById(borrowerid);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public List<Book> getBooksByUser(String user) throws Exception{
		try {
			List<Book> booksList = new ArrayList<>();
			List<Borrower> borrowers = borrowerRepo.findBorrowersByUser(user);
			borrowers.stream().forEach(borrower -> {
				booksList.add(borrower.getBook());
			});
			return booksList;
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
}
