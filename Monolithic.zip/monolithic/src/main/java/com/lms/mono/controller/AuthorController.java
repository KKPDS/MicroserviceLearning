package com.lms.mono.controller;

import com.lms.mono.entity.Author;
import com.lms.mono.service.AuthorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/authors")
public class AuthorController {

	@Autowired
	AuthorService authorService;
	
	@GetMapping
	public List<Author> getAuthors() throws Exception{
		List<Author> authors = authorService.getAuthors();
		return authors;
	}
	
	@GetMapping(value ="{id}")
	public Author getAuthor(@PathVariable int id) throws Exception{
		Author author = authorService.getAuthorById(id);
		return author;
	}
	
	@PostMapping
	public List<Author> addAuthor(@RequestBody Author author) throws Exception {
		authorService.addAuthor(author);
		return authorService.getAuthors();
	}
	
	@PutMapping(value = "{id}")
	public Author updateAuthor(@PathVariable int id, @RequestBody Author author) throws Exception {
		authorService.updateAuthor(id, author);
		return authorService.getAuthorById(id);
	}
	
	@DeleteMapping(value = "{id}")
	public String removeAuthor(@PathVariable int id) throws Exception {
		authorService.removeAuthor(id);
		return "OK";
	}
	
}
