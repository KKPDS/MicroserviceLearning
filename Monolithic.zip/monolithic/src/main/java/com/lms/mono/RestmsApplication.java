package com.lms.mono;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestmsApplication.class, args);
	}

}
