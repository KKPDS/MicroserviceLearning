package com.lms.mono.service;

import com.lms.mono.entity.Author;
import com.lms.mono.repository.AuthorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class AuthorService {
	@Autowired
	AuthorRepository authorRepo;
	
	public List<Author> getAuthors() throws Exception{
		try {
			return (List<Author>) authorRepo.findAll();
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	public Author getAuthorById(Integer authorid) throws Exception{
		Author author = null;
		try {
			author = authorRepo.findById(authorid).orElse(null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return author;
	}
	
	public Author addAuthor(Author author) throws Exception{
		try {
			return authorRepo.save(author);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	public Author updateAuthor(Integer authorid, Author author) throws Exception{
		try {
			Author existingauthor = authorRepo.findById(authorid).orElse(null);
			if (null != existingauthor) {
				existingauthor.setName(author.getName());
				existingauthor.setCountry(author.getCountry());
				return authorRepo.save(existingauthor);
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return null;
	}
	
	public void removeAuthor(Integer authorid) throws Exception{
		try {
			authorRepo.deleteById(authorid);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
}
