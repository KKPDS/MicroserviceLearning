package com.lms.mono.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;
import java.sql.Date;


/**
 * The persistent class for the borrower database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@NamedQuery(name="Borrower.findAll", query="SELECT b FROM Borrower b")
public class Borrower implements Serializable {
	@Serial
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id;

	@OneToOne
	@JoinColumn(name="book_id")
	private Book book;

	@Column(name="borrow_date")
	private Date borrowDate;

	@Column(name="return_date")
	private Date returnDate;

	@Column(name="user")
	private String user;

}