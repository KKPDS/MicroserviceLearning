package com.lms.service1.model;

import jakarta.persistence.*;
import lombok.*;

import java.io.Serial;
import java.io.Serializable;

/**
 * The persistent class for the author database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Author implements Serializable {
	private int id;
	private String name;
	private String country;
}