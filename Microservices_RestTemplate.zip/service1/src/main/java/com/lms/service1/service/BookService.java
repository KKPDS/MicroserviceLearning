package com.lms.service1.service;

import com.lms.service1.entity.Book;
import com.lms.service1.model.Author;
import com.lms.service1.repository.BookRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;


@Service
public class BookService {
	private static final Logger log = LoggerFactory.getLogger(BookService.class);


	@Autowired
	BookRepository bookRepo;

	@Autowired
	private RestTemplate restTemplate;


	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}

	public List<Book> getBooks() throws Exception{
		try {
			return (List<Book>) bookRepo.findAll();
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	//	public List<Book> getBooksByAuthorId(int authorid) throws Exception{
	//		try {
	//			return (List<Book>) bookRepo.findBooksByAuthorid(authorid);
	//		} catch (Exception e) {
	//			throw new Exception(e.getMessage());
	//		}
	//	}
	
	public Book getBookById(Integer bookid) throws Exception{
		Book book = null;
		try {
			book = bookRepo.findById(bookid).orElse(null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return book;
	}


	public List<Book> getBooksByAuthorId(Integer authorId) throws Exception {
		List<Book> result = null;
		try{
			result = bookRepo.findBooksByAuthorid(authorId);
			// Author author = restTemplate.getForObject("http://localhost:8087/api/authors/" + authorId, Author.class);
			result.stream().forEach(book -> {
				Author author = restTemplate.getForObject("http://localhost:8087/api/authors/" + book.getAuthorid(), Author.class);
				book.setAuthor(author);
			});
		}catch (Exception e){
			throw new Exception(e.getMessage());
		}
		return result;
	}

	public void addBook(Book book) throws Exception{
		try {
			bookRepo.save(book);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	public void updateBook(Integer bookid, Book book) throws Exception{
		try {
			Book existingbook = bookRepo.findById(bookid).orElse(null);
			if (null != existingbook) {
				existingbook.setTitle(book.getTitle());
				existingbook.setIsbn(book.getIsbn());
				existingbook.setAuthorid(book.getAuthorid());
				existingbook.setStatus(book.getStatus());
				bookRepo.save(existingbook);
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	public void removeBook(Integer bookid) throws Exception{
		try {
			bookRepo.deleteById(bookid);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public Author getAuthorById(Long authorId) {
		return restTemplate.getForObject("http://localhost:8087/api/authors/" + authorId, Author.class);
	}

	public Author getAuthorByBookId(Integer bookid) {
		Author author = null;
		try {
			Book book = bookRepo.findById(bookid).orElse(null);
			if (null != book) {
				author = restTemplate.getForObject("http://localhost:8087/api/authors/" + book.getAuthorid(), Author.class);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return author;
	}
	
}
