package com.lms.service1.controller;

import com.lms.service1.entity.Book;
import com.lms.service1.model.Author;
import com.lms.service1.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/books")
public class BookController {

	@Autowired
	BookService bookService;
	
	@GetMapping
	public List<Book> getBooks() throws Exception{
		List<Book> books = bookService.getBooks();
		return books;
	}

	@GetMapping(value ="{id}")
	public Book getBook(@PathVariable int id) throws Exception{
		Book book = bookService.getBookById(id);
		return book;
	}

	@PostMapping
	public List<Book> addBook(@RequestBody Book book) throws Exception {
		bookService.addBook(book);
		return bookService.getBooks();
	}

	@PutMapping(value = "{id}")
	public Book updateBook(@PathVariable int id, @RequestBody Book book) throws Exception {
		bookService.updateBook(id, book);
		return bookService.getBookById(id);
	}
	
	@DeleteMapping(value = "{id}")
	public String removeBook(@PathVariable int id) throws Exception {
		bookService.removeBook(id);
		return "OK";
	}

	@GetMapping(value ="author/{id}")
	public List<Book> getBooksByAuthorId(@PathVariable int id) throws Exception{
		List<Book> books = bookService.getBooksByAuthorId(id);
		return books;
	}

	@GetMapping(value ="authors/{id}")
	public Author getAuthorByBookId(@PathVariable int id) throws Exception{
		Author author = bookService.getAuthorByBookId(id);
		return author;
	}

	
}
