package com.lms.service3.entity;

import jakarta.persistence.*;
import lombok.*;

import java.io.Serializable;


/**
 * The persistent class for the book database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Book implements Serializable {
	private int id;
	private String title;
	private String isbn;
	private int authorid;
	private String status;
}