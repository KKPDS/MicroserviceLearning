package com.lms.service3.repository;

import com.lms.service3.entity.Borrower;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BorrowerRepository extends JpaRepository<Borrower, Integer> {
    List<Borrower> findBorrowersByUser(String user);
}
