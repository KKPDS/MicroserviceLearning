package com.lms.service3.service;

import com.lms.service3.entity.Book;
import com.lms.service3.entity.Borrower;
import com.lms.service3.repository.BorrowerRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;


@Service
public class BorrowerService {
	private static final Logger log = LoggerFactory.getLogger(BorrowerService.class);

	@Autowired
	BorrowerRepository borrowerRepo;

	@Autowired
	private RestTemplate restTemplate;


	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}

	public List<Borrower> getBorrowers() throws Exception{
		try {
			return (List<Borrower>) borrowerRepo.findAll();
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	public Borrower getBorrowerById(Integer borrowerid) throws Exception{
		Borrower borrower = null;
		try {
			borrower = borrowerRepo.findById(borrowerid).orElse(null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return borrower;
	}
	
	public void addBorrower(Borrower borrower) throws Exception{
		try {
			Integer bookid = borrower.getBookId();
			if (null != bookid) {
				borrowerRepo.save(borrower);
				Book book = restTemplate.getForObject("http://localhost:8086/api/books/" + bookid, Book.class);
				book.setStatus("BORROWED");
				HttpEntity<Book> bookHttpEntity = new HttpEntity<>(book);
				restTemplate.exchange("http://localhost:8086/api/books/" + bookid, HttpMethod.PUT, bookHttpEntity, Book.class);
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	public void updateBorrower(Integer borrowerid, Borrower borrower) throws Exception{
		try {
			Borrower existingborrower = borrowerRepo.findById(borrowerid).orElse(null);
			if (null != existingborrower) {
				existingborrower.setBookId(borrower.getBookId());
				existingborrower.setBorrowDate(borrower.getBorrowDate());
				existingborrower.setReturnDate(borrower.getReturnDate());
				existingborrower.setUser(borrower.getUser());
				borrowerRepo.save(existingborrower);
				if (null != borrower.getReturnDate()) {
					Integer bookid = borrower.getBookId();
					Book book = restTemplate.getForObject("http://localhost:8086/api/books/" + bookid, Book.class);
					book.setStatus("AVAILABLE");
					HttpEntity<Book> bookHttpEntity = new HttpEntity<>(book);
					restTemplate.exchange("http://localhost:8086/api/books/" + bookid, HttpMethod.PUT, bookHttpEntity, Book.class);
				}

			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	public void removeBorrower(Integer borrowerid) throws Exception{
		try {
			Borrower borrower = borrowerRepo.findById(borrowerid).orElse(null);
			if (null != borrower) {
				List<Borrower> borrowers = borrowerRepo.findBorrowersByUser(borrower.getUser());
				borrowers.stream().forEach(borrowal -> {
					Integer bookid = borrower.getBookId();
					Book book = restTemplate.getForObject("http://localhost:8086/api/books/" + bookid, Book.class);
					book.setStatus("AVAILABLE");
					HttpEntity<Book> bookHttpEntity = new HttpEntity<>(book);
					restTemplate.exchange("http://localhost:8086/api/books/" + bookid, HttpMethod.PUT, bookHttpEntity, Book.class);
				});
			}
			borrowerRepo.deleteById(borrowerid);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public List<Book> getBooksByUser(String user) throws Exception{
		List<Book> bookList = new ArrayList<>();
		try {
			List<Borrower> borrowers = borrowerRepo.findBorrowersByUser(user);
			if (borrowers.size() > 0) {
				borrowers.stream().forEach(borrowal -> {
					Integer bookid = borrowal.getBookId();
					Book book = restTemplate.getForObject("http://localhost:8086/api/books/" + bookid, Book.class);
					bookList.add(book);
				});
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return bookList;
	}
}
