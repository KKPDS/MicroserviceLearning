package com.lms.service3.controller;

import com.lms.service3.entity.Book;
import com.lms.service3.entity.Borrower;
import com.lms.service3.service.BorrowerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/borrowers")
public class BorrowerController {

	@Autowired
	BorrowerService borrowerService;
	
	@GetMapping
	public List<Borrower> getBorrowers() throws Exception{
		List<Borrower> borrowers = borrowerService.getBorrowers();
		return borrowers;
	}
	
	@GetMapping(value ="{id}")
	public Borrower getBorrower(@PathVariable int id) throws Exception{
		Borrower borrower = borrowerService.getBorrowerById(id);
		return borrower;
	}

	@GetMapping(value ="user/{name}")
	public List<Book> getBooksByUser(@PathVariable String name) throws Exception{
		List<Book> books = borrowerService.getBooksByUser(name);
		return books;
	}
	
	@PostMapping
	public List<Borrower> addBorrower(@RequestBody Borrower borrower) throws Exception {
		borrowerService.addBorrower(borrower);
		return borrowerService.getBorrowers();
	}
	
	@PutMapping(value = "{id}")
	public Borrower updateBorrower(@PathVariable int id, @RequestBody Borrower borrower) throws Exception {
		borrowerService.updateBorrower(id, borrower);
		return borrowerService.getBorrowerById(id);
	}
	
	@DeleteMapping(value = "{id}")
	public String removeBorrower(@PathVariable int id) throws Exception {
		borrowerService.removeBorrower(id);
		return "OK";
	}
	
}
