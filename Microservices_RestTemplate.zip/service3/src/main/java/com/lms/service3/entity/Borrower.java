package com.lms.service3.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

import java.io.Serial;
import java.io.Serializable;
import java.sql.Date;


/**
 * The persistent class for the borrower database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@NamedQuery(name="Borrower.findAll", query="SELECT b FROM Borrower b")
public class Borrower implements Serializable {
	@Serial
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id;

	@Column(name="book_id")
	private int bookId;

	@Column(name="borrow_date")
	private Date borrowDate;

	@Column(name="return_date")
	private Date returnDate;

	@Column(name="user")
	private String user;

}