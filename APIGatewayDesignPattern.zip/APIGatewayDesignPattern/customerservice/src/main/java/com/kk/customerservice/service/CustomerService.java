package com.kk.customerservice.service;

import com.kk.customerservice.model.Customer;
import com.kk.customerservice.repository.CustomerRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class CustomerService {
	private static final Logger log = LoggerFactory.getLogger(CustomerService.class);

	@Autowired
	CustomerRepository customerRepository;

	public List<Customer> getCustomers() throws Exception{
		try {
			return (List<Customer>) customerRepository.findAll();
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public Customer getCustomerById(Long customerid) throws Exception{
		Customer customer = null;
		try {
			customer = customerRepository.findById(customerid).orElse(null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return customer;
	}

	public Customer addCustomer(Customer customer) throws Exception{
		try {
			return customerRepository.save(customer);
		} catch (Exception pe) {
			pe.printStackTrace();
		}
		return null;
	}
	
	public Customer updateCustomer(Long customerid, Customer order) throws Exception {
		Customer existingcustomer = customerRepository.findById(customerid).orElse(null);
		if (null != existingcustomer) {
			existingcustomer.setId(order.getId());
			existingcustomer.setName(order.getName());
			return customerRepository.save(existingcustomer);
		}
		return null;
	}
	
	public void removeCustomer(Long customerid) throws Exception{
		try {
			customerRepository.deleteById(customerid);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

}
