package com.kk.customerservice.controller;

import com.kk.customerservice.model.Customer;
import com.kk.customerservice.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/customers")
public class CustomerController {

	@Autowired
	CustomerService customerService;
	
	@GetMapping
	public List<Customer> getCustomers() throws Exception{
		List<Customer> customers = customerService.getCustomers();
		return customers;
	}

	@GetMapping(value ="{id}")
	public ResponseEntity<Customer> getCustomer(@PathVariable Long id) throws Exception{
		Customer customer = customerService.getCustomerById(id);
		return ResponseEntity.ok(customer);
	}

	@PostMapping
	public ResponseEntity<Customer> addCustomer(@RequestBody Customer customer) throws Exception {
		Customer savedcustomer = customerService.addCustomer(customer);
		return ResponseEntity.ok(savedcustomer);
	}

	@PutMapping(value = "{id}")
	public Customer updateCustomer(@PathVariable Long id, @RequestBody Customer customer) throws Exception {
		return customerService.updateCustomer(id, customer);
	}
	
	@DeleteMapping(value = "{id}")
	public String removeCustomer(@PathVariable Long id) throws Exception {
		customerService.removeCustomer(id);
		return "OK";
	}

}
