package com.kk.orderservice.controller;

import com.kk.orderservice.model.CustomerOrder;
import com.kk.orderservice.service.CustomerOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/customerorders")
public class CustomerOrderController {

	@Autowired
	CustomerOrderService customerOrderService;
	
	@GetMapping
	public List<CustomerOrder> getCustomerOrders() throws Exception{
		List<CustomerOrder> customerOrders = customerOrderService.getCustomerOrders();
		return customerOrders;
	}

	@GetMapping(value ="{id}")
	public ResponseEntity<CustomerOrder> getCustomerOrder(@PathVariable Long id) throws Exception{
		CustomerOrder customerOrder = customerOrderService.getCustomerOrderById(id);
		return ResponseEntity.ok(customerOrder);
	}

	@PostMapping
	public ResponseEntity<CustomerOrder> addCustomerOrder(@RequestBody CustomerOrder customerOrder) throws Exception {
		CustomerOrder savedcustomerOrder = customerOrderService.addCustomerOrder(customerOrder);
		return ResponseEntity.ok(savedcustomerOrder);
	}

	@PutMapping(value = "{id}")
	public CustomerOrder updateCustomerOrder(@PathVariable Long id, @RequestBody CustomerOrder customerOrder) throws Exception {
		return customerOrderService.updateCustomerOrder(id, customerOrder);
	}
	
	@DeleteMapping(value = "{id}")
	public String removeCustomerOrder(@PathVariable Long id) throws Exception {
		customerOrderService.removeCustomerOrder(id);
		return "OK";
	}

}
