package com.kk.orderservice.service;

import com.kk.orderservice.model.CustomerOrder;
import com.kk.orderservice.repository.CustomerOrderRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class CustomerOrderService {
	private static final Logger log = LoggerFactory.getLogger(CustomerOrderService.class);

	@Autowired
	CustomerOrderRepository customerOrderRepository;

	public List<CustomerOrder> getCustomerOrders() throws Exception{
		try {
			return (List<CustomerOrder>) customerOrderRepository.findAll();
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public CustomerOrder getCustomerOrderById(Long customerorderid) throws Exception{
		CustomerOrder customerorder = null;
		try {
			customerorder = customerOrderRepository.findById(customerorderid).orElse(null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return customerorder;
	}

	public CustomerOrder addCustomerOrder(CustomerOrder customerorder) throws Exception{
		try {
			return customerOrderRepository.save(customerorder);
		} catch (Exception pe) {
			pe.printStackTrace();
		}
		return null;
	}
	
	public CustomerOrder updateCustomerOrder(Long customerorderid, CustomerOrder order) throws Exception {
		CustomerOrder existingcustomerorder = customerOrderRepository.findById(customerorderid).orElse(null);
		if (null != existingcustomerorder) {
			existingcustomerorder.setId(order.getId());
			existingcustomerorder.setProduct(order.getProduct());
			existingcustomerorder.setCustomerId(order.getCustomerId());
			return customerOrderRepository.save(existingcustomerorder);
		}
		return null;
	}
	
	public void removeCustomerOrder(Long customerorderid) throws Exception{
		try {
			customerOrderRepository.deleteById(customerorderid);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

}
